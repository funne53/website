// /admin/dashboard.js
import { useEffect } from "react";
import { useRouter } from "next/router";

const ADMIN_USERNAME = "MILLEX6666";

// TEMP mock users (later from DB)
const USERS = [
  {
    username: "millex",
    badges: ["admin", "verified", "nitro"],
    theme: "default",
  },
  {
    username: "testuser",
    badges: ["verified"],
    theme: "default",
  },
];

export default function AdminDashboard() {
  const router = useRouter();
  const { user } = router.query;

  useEffect(() => {
    if (!user || user !== ADMIN_USERNAME) {
      router.replace("/403");
    }
  }, [user]);

  if (user !== ADMIN_USERNAME) return null;

  return (
    <div style={styles.wrap}>
      <h1>🛡 Admin Dashboard</h1>
      <p>Logged as <b>{ADMIN_USERNAME}</b></p>

      <div style={styles.list}>
        {USERS.map((u) => (
          <div key={u.username} style={styles.card}>
            <h3>@{u.username}</h3>
            <p>Theme: {u.theme}</p>
            <p>Badges: {u.badges.join(", ") || "none"}</p>

            <button
              onClick={() =>
                router.push(`/admin/userManagement?user=${ADMIN_USERNAME}&target=${u.username}`)
              }
            >
              Manage User
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}

const styles = {
  wrap: {
    minHeight: "100vh",
    background: "#000",
    color: "#fff",
    padding: "40px",
    fontFamily: "Inter, sans-serif",
  },
  list: {
    display: "grid",
    gridTemplateColumns: "repeat(auto-fill, minmax(260px, 1fr))",
    gap: "20px",
    marginTop: "30px",
  },
  card: {
    background: "rgba(255,255,255,0.05)",
    border: "1px solid rgba(255,255,255,0.1)",
    borderRadius: "14px",
    padding: "20px",
  },
};
