// /admin/userManagement.js
import { useEffect, useState } from "react";
import { useRouter } from "next/router";

const ADMIN_USERNAME = "MILLEX6666";

const ALL_BADGES = ["admin", "verified", "nitro", "achievement"];

export default function UserManagement() {
  const router = useRouter();
  const { user, target } = router.query;

  const [badges, setBadges] = useState(["verified"]);
  const [theme, setTheme] = useState("default");

  useEffect(() => {
    if (!user || user !== ADMIN_USERNAME) {
      router.replace("/403");
    }
  }, [user]);

  if (user !== ADMIN_USERNAME) return null;

  const toggleBadge = (badge) => {
    setBadges((prev) =>
      prev.includes(badge)
        ? prev.filter((b) => b !== badge)
        : [...prev, badge]
    );
  };

  const resetUser = () => {
    setBadges([]);
    setTheme("default");
    alert("User reset (mock)");
  };

  return (
    <div style={styles.wrap}>
      <h1>⚙ Managing @{target}</h1>

      <section style={styles.section}>
        <h3>Badges</h3>
        {ALL_BADGES.map((b) => (
          <label key={b} style={styles.checkbox}>
            <input
              type="checkbox"
              checked={badges.includes(b)}
              onChange={() => toggleBadge(b)}
            />
            {b}
          </label>
        ))}
      </section>

      <section style={styles.section}>
        <h3>Theme</h3>
        <select value={theme} onChange={(e) => setTheme(e.target.value)}>
          <option value="default">default</option>
        </select>
      </section>

      <div style={{ marginTop: 30 }}>
        <button onClick={resetUser} style={styles.danger}>
          Reset User
        </button>
      </div>
    </div>
  );
}

const styles = {
  wrap: {
    minHeight: "100vh",
    background: "#000",
    color: "#fff",
    padding: "40px",
    fontFamily: "Inter, sans-serif",
  },
  section: {
    marginTop: "25px",
  },
  checkbox: {
    display: "block",
    marginBottom: "10px",
  },
  danger: {
    background: "#ff2b2b",
    border: "none",
    color: "#fff",
    padding: "12px 18px",
    borderRadius: "10px",
    cursor: "pointer",
  },
};
