// /components/TopButtons.js
import React from "react";

export default function TopButtons({ buttons = [] }) {
  return (
    <div className="top-buttons">
      {buttons.map((btn, i) => (
        <a key={i} href={btn.url} target="_blank" rel="noopener noreferrer">
          {btn.icon ? (
            <img
              src={btn.icon}
              alt={btn.title}
              className="btn-icon"
            />
          ) : (
            <span className="btn-icon">{btn.title[0]}</span>
          )}
        </a>
      ))}
    </div>
  );
}
