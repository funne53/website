// /components/GlowParticles.js
import React, { useEffect } from "react";

export default function GlowParticles() {
  useEffect(() => {
    const pEl = document.getElementById("particles");
    for (let i = 0; i < 30; i++) {
      const el = document.createElement("div");
      el.className = `particle ${Math.random() > 0.5 ? "p-s" : "p-m"}`;
      el.style.left = Math.random() * 100 + "vw";
      el.style.top = Math.random() * 100 + "vh";
      el.style.animationDuration = 15 + Math.random() * 20 + "s";
      pEl.appendChild(el);
    }
  }, []);

  return <div className="particles" id="particles"></div>;
}
