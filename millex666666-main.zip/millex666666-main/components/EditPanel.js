// /components/EditPanel.js
import React, { useState } from "react";

export default function EditPanel({ user, onSave }) {
  const [bio, setBio] = useState(user.bio || "");
  const [customCSS, setCustomCSS] = useState(user.customCSS || "");
  const [badges, setBadges] = useState(user.badges || []);

  const toggleBadge = (badgeId) => {
    setBadges((prev) =>
      prev.includes(badgeId)
        ? prev.filter((b) => b !== badgeId)
        : [...prev, badgeId]
    );
  };

  const handleSave = () => {
    onSave({
      ...user,
      bio,
      badges,
      customCSS,
    });
  };

  return (
    <div className="edit-panel card glow">
      <h3>Edit Profile</h3>
      <label>Bio:</label>
      <textarea
        value={bio}
        onChange={(e) => setBio(e.target.value)}
        rows={3}
      />

      <label>Custom CSS:</label>
      <textarea
        value={customCSS}
        onChange={(e) => setCustomCSS(e.target.value)}
        rows={4}
      />

      <label>Badges:</label>
      <div className="badges">
        {["admin", "verified", "nitro", "achievement"].map((b) => (
          <img
            key={b}
            src={`/badges/${b}.png`}
            className={`badge ${badges.includes(b) ? "glow-soft" : ""}`}
            alt={b}
            onClick={() => toggleBadge(b)}
            style={{ cursor: "pointer" }}
          />
        ))}
      </div>

      <button className="btn" onClick={handleSave}>
        Save Changes
      </button>
    </div>
  );
}
