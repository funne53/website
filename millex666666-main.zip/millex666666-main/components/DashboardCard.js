// /components/DashboardCard.js
import React from "react";
import { parseBadges } from "../utils/helpers";

export default function DashboardCard({ user }) {
  const badges = parseBadges(user.badges || []);

  return (
    <div className="card glow">
      <img
        className="avatar"
        src={user.avatar || "/public/cursors/cursor.png"}
        alt={user.username}
      />
      <div className="name">{user.username}</div>
      <div className="about">{user.bio || "No bio yet..."}</div>

      <div className="badges">
        {badges.map((b) => (
          <img
            key={b.id}
            className={`badge ${b.id}`}
            src={b.icon}
            alt={b.label}
            title={b.label}
          />
        ))}
      </div>
    </div>
  );
}
