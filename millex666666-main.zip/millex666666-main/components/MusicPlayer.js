// /components/MusicPlayer.js
import React, { useState, useRef, useEffect } from "react";

export default function MusicPlayer({ playlist = [] }) {
  const [index, setIndex] = useState(0);
  const [playing, setPlaying] = useState(false);
  const audioRef = useRef(new Audio());

  const current = playlist[index] || {};

  useEffect(() => {
    audioRef.current.src = current.url || "";
    if (playing) audioRef.current.play();
  }, [index, current.url, playing]);

  const togglePlay = () => {
    if (playing) audioRef.current.pause();
    else audioRef.current.play();
    setPlaying(!playing);
  };

  const next = () => setIndex((i) => (i + 1) % playlist.length);
  const prev = () => setIndex((i) => (i - 1 + playlist.length) % playlist.length);

  return (
    <div className="music-player glow">
      <img className="track-art" src={current.img} alt={current.title} />
      <div className="track-info">
        <div className="track-name">{current.title || "No track"}</div>
      </div>
      <div className="player-controls">
        <button className="ctrl-btn" onClick={prev}>⏮</button>
        <button className="ctrl-btn" onClick={togglePlay}>{playing ? "⏸" : "▶️"}</button>
        <button className="ctrl-btn" onClick={next}>⏭</button>
      </div>
    </div>
  );
}
