// /pages/api/saveUser.js
export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({ error: "POST only" });

  const { username, updates } = req.body;
  if (!username || !updates) return res.status(400).json({ error: "Missing data" });

  try {
    // For now, just simulate saving
    console.log("Saving user updates for:", username);
    console.log(updates);

    // TODO: later save to DB / JSON / Cloudinary
    res.status(200).json({ success: true, message: "User updates saved!" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}
