// /pages/api/getUser.js
export default async function handler(req, res) {
  const { username } = req.query;

  if (!username) return res.status(400).json({ error: "No username provided" });

  try {
    // For now, simple local JSON simulation
    // Later: can replace with database or Cloudinary JSON
    const data = {
      username,
      bio: "Developing C# | Python | Lua | 3D enthusiast",
      theme: "default",
      buttons: [
        { title: "Discord", url: "https://discord.gg/HdGasSNbys", icon: "/public/icons/default-icon.png" }
      ],
      badges: username.toLowerCase() === "millex6666" ? ["admin", "verified"] : ["verified"],
      music: []
    };

    res.status(200).json(data);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}
