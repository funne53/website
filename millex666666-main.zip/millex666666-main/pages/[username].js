// /pages/[username].js
import { useRouter } from "next/router";
import { useEffect, useState } from "react";
import TopButtons from "../components/TopButtons";
import MusicPlayer from "../components/MusicPlayer";
import DashboardCard from "../components/DashboardCard";

export default function UserPage() {
  const router = useRouter();
  const { username } = router.query;
  const [userData, setUserData] = useState(null);

  useEffect(() => {
    if (!username) return;
    fetch(`/api/getUser?username=${username}`)
      .then(res => res.json())
      .then(data => setUserData(data));
  }, [username]);

  if (!userData) return <div style={{ color: "#fff" }}>Loading...</div>;

  return (
    <div style={{ background: "#000", minHeight: "100vh", color: "#fff", padding: "20px" }}>
      <DashboardCard user={userData} />
      <TopButtons buttons={userData.buttons} />
      <MusicPlayer playlist={userData.music} />
    </div>
  );
}
