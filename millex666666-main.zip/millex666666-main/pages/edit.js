// /pages/edit.js
import EditPanel from "../components/EditPanel";

export default function EditPage() {
  return (
    <div style={{ background: "#111", minHeight: "100vh", color: "#fff", padding: "20px" }}>
      <h1>Edit Your Dashboard</h1>
      <EditPanel />
    </div>
  );
}
