// /pages/index.js
import { useEffect } from "react";

export default function Home() {
  const clientId = process.env.NEXT_PUBLIC_DISCORD_CLIENT_ID;
  const redirectUri = encodeURIComponent(`${process.env.NEXT_PUBLIC_BASE_URL}/pages/callback`);
  const scope = "identify";

  const discordLogin = () => {
    window.location.href = `https://discord.com/api/oauth2/authorize?client_id=${clientId}&redirect_uri=${redirectUri}&response_type=code&scope=${scope}`;
  };

  return (
    <div style={{ height: "100vh", display: "flex", justifyContent: "center", alignItems: "center", background: "#000", color: "#fff" }}>
      <button
        onClick={discordLogin}
        style={{
          padding: "16px 24px",
          fontSize: "18px",
          borderRadius: "12px",
          cursor: "pointer",
          background: "#7289DA",
          border: "none",
          color: "#fff"
        }}
      >
        Login with Discord
      </button>
    </div>
  );
}
