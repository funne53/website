// /pages/callback.js
import { useEffect } from "react";
import { useRouter } from "next/router";

export default function Callback() {
  const router = useRouter();
  const { code } = router.query;

  useEffect(() => {
    if (!code) return;

    async function fetchUser() {
      const data = await fetch("/api/discordAuth", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ code })
      }).then(res => res.json());

      if (data.username) {
        router.push(`/@${data.username}`);
      }
    }

    fetchUser();
  }, [code]);

  return <div style={{ color: "#fff", textAlign: "center", marginTop: "40vh" }}>Logging in...</div>;
}
