// /utils/helpers.js

export const ADMIN_USERNAME = "MILLEX6666";

/* ================= ADMIN ================= */

export function isAdmin(username) {
  if (!username) return false;
  return username.toLowerCase() === ADMIN_USERNAME.toLowerCase();
}

/* ================= USERNAME ================= */

export function normalizeUsername(username) {
  return username
    .toLowerCase()
    .replace(/[^a-z0-9_]/g, "");
}

/* ================= BADGES ================= */

export const BADGES = {
  admin: {
    id: "admin",
    label: "Admin",
    icon: "/badges/admin.png",
  },
  verified: {
    id: "verified",
    label: "Verified",
    icon: "/badges/verified.png",
  },
  nitro: {
    id: "nitro",
    label: "Nitro",
    icon: "/badges/nitro.png",
  },
  achievement: {
    id: "achievement",
    label: "Achievement",
    icon: "/badges/achievement.png",
  },
};

export function parseBadges(badges = []) {
  return badges
    .filter((b) => BADGES[b])
    .map((b) => BADGES[b]);
}

/* ================= THEME ================= */

export function parseTheme(userTheme, defaultTheme) {
  if (!userTheme) return defaultTheme;

  return {
    ...defaultTheme,
    ...userTheme,
    colors: {
      ...defaultTheme.colors,
      ...userTheme.colors,
    },
    glow: {
      ...defaultTheme.glow,
      ...userTheme.glow,
    },
  };
}
