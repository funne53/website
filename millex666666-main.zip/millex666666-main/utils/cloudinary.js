// /utils/cloudinary.js

export const CLOUDINARY_UPLOAD_URL =
  "https://api.cloudinary.com/v1_1/YOUR_CLOUD_NAME/auto/upload";

export async function uploadToCloudinary(file, uploadPreset) {
  const form = new FormData();
  form.append("file", file);
  form.append("upload_preset", uploadPreset);

  const res = await fetch(CLOUDINARY_UPLOAD_URL, {
    method: "POST",
    body: form,
  });

  if (!res.ok) {
    throw new Error("Upload failed");
  }

  return await res.json();
}
